import bot
bot.run_discord_bot()